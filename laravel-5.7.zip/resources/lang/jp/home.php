<?php

return [
	'language_menu' => '言語',
	'logout_menu' => 'ログアウト',
	'admin_menu' => '管理',
	'contact_menu' => '接触',
    'Home_title' => 'ホームページ',
    'about_company' => '会社について',
    'article' => '記事',
    'contactus' => 'お問い合わせ',
    'letstalk' => '話しましょう！',
    'contact_name' => '名',
    'contact_email' => 'Eメール',
    'contact_comment' => 'コメント',
    'contact_submit' => '提出する',
];
