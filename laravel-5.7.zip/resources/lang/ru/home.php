<?php

return [
	'language_menu' => 'язык',
	'logout_menu' => 'Выйти',
	'admin_menu' => 'Администратор',
	'contact_menu' => 'контакт',
    'Home_title' => 'Главная страница',
    'about_company' => 'О компании',
    'article' => 'статьи',
    'contactus' => 'связаться с нами',
    'letstalk' => 'Давайте поговорим!',
    'contact_name' => 'название',
    'contact_email' => 'Эл. адрес',
    'contact_comment' => 'Комментарий',
    'contact_submit' => 'Отправить',
];
