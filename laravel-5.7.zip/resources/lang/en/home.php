<?php

return [
    'language_menu' => 'Language',
    'logout_menu' => 'Logout',
    'admin_menu' => 'Admin',
    'contact_menu' => 'Contact',
    'Home_title' => 'Home page',
    'about_company' => 'About Company',
    'article' => 'Articles',
    'contactus' => 'Contact US',
    'letstalk' => 'Let\'s talk!',
    'contact_name' => 'Name',
    'contact_email' => 'Email',
    'contact_comment' => 'Comment',
    'contact_submit' => 'Submit',
];
