<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Article extends Model
{
    //
    public $timestamps = true;    
    protected $table = 'articles';

    protected $fillable = ['article_name', 'author', 'content']; 
    protected $guarded = ['created_at', 'updated_at'];
}
