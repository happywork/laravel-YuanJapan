<?php $__env->startSection('template_title'); ?>
    Homepage
<?php $__env->stopSection(); ?>

<?php $__env->startSection('template_fastload_css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-10 offset-lg-1">
                

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_scripts'); ?>
<div id="footer-wrap">
	<div class="row">
		<div class="large-12 columns">
			<footer class="row footer">
				<div class="large-3 columns">
					<aside class="widget group">
						<h3 class="widget-title">Text Widget</h3>
						<div class="widget-content">
							<p>Nulla at nulla justo, eget luctus tortor. Nulla facilisi. Duis aliquet egestas purus in blandit. Curabitur vulputate, ligula lacinia scelerisque tempor, lacus lacus ornare ante. Nulla at nulla justo, eget luctus tortor. Nulla facilisi. Duis aliquet egestas purus.</p>
						</div>
					</aside><!-- /widget -->
				</div>
				<div class="large-3 columns">
					<aside class="widget widget_ci_about group">
						<h3 class="widget-title">About Widget</h3>
						<div class="widget_about widget-content group">
							<img src="http://dummyimage.com/100x100/000000/fff.png" class="alignleft" alt="about me">
							Nam vestibulum, arcu sodales feugiat consectetur, nisl orci bibendum elit, eu euismod magna sapien ut nibh. Donec semper quam scelerisque tortor dictum gravida.
						</div>
					</aside>
				</div>
				<div class="large-3 columns">
					<aside class="widget group">
						<h3 class="widget-title">Text Widget</h3>
						<div class="widget-content">
							<p>Nulla at nulla justo, eget luctus tortor. Nulla facilisi. Duis aliquet egestas purus in blandit. Curabitur vulputate, ligula lacinia scelerisque tempor, lacus lacus ornare ante. Nulla at nulla justo, eget luctus tortor. Nulla facilisi. Duis aliquet egestas purus.</p>
						</div>
					</aside><!-- /widget -->
				</div>
				<div class="large-3 columns">
					<aside class="widget group">
						<h3 class="widget-title">Text Widget</h3>
						<div class="widget-content">
							<p>Nulla at nulla justo, eget luctus tortor. Nulla facilisi. Duis aliquet egestas purus in blandit. Curabitur vulputate, ligula lacinia scelerisque tempor, lacus lacus ornare ante. Nulla at nulla justo, eget luctus tortor. Nulla facilisi. Duis aliquet egestas purus.</p>
						</div>
					</aside><!-- /widget -->
				</div>
			</footer><!-- /footer -->
		</div><!-- /large-12 -->
	</div><!-- /row -->
</div><!-- /footer-wrap -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('credits_wrap'); ?>
<div id="credits-wrap">
	<div class="row">
		<div class="large-12 columns">
			<div class="row credits">
				<div class="large-6 columns">
					An entertainment site template
				</div>
				<div class="large-6 columns text-right">
					Made in <a href="http://www.cssigniter.com">cssigniter.com</a>
				</div>				
			</div><!-- /row -->
		</div><!-- /large-12 -->
	</div><!-- /row -->
</div><!-- /credits-wrap -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>