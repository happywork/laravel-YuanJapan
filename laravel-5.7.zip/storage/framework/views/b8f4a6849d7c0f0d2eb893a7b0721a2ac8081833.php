<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php if(trim($__env->yieldContent('template_title'))): ?><?php echo $__env->yieldContent('template_title'); ?> | <?php endif; ?> <?php echo e(config('app.name', Lang::get('titles.app'))); ?></title>
        <meta name="description" content="">
        <meta name="author" content="Maxsim">
        <link rel="shortcut icon" href="/favicon.ico">

        
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

        
        <?php echo $__env->yieldContent('template_linked_fonts'); ?>

                
        <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
        <link href="<?php echo e(asset('css/normalize.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/foundation.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/flexslider.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/prettyPhoto.css')); ?>" rel="stylesheet">        
        <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">                 
        <link href="<?php echo e(asset('css/default.css')); ?>" rel="stylesheet">
        
        <script type="text/javascript" src="<?php echo e(asset('js/modernizr.js')); ?>"></script>        
        <script src="http://maps.google.com/maps/api/js?sensor=false"></script>

        <?php echo $__env->yieldContent('template_linked_css'); ?>

        <style type="text/css">
            <?php echo $__env->yieldContent('template_fastload_css'); ?>
        </style>

        
        <script>
            window.Laravel = <?php echo json_encode([
                'csrfToken' => csrf_token(),
            ]); ?>;
        </script>        

        <?php echo $__env->yieldContent('head'); ?>

    </head>
    <body class="home">
    <div id="mobile-bar">
		<a class="menu-trigger" href="#"></a>
		<h1 class="mob-title">Club 88</h1>
	</div>
 
    <div id="header-wrap">  
        <div id="top-wrap">
            <div class="row">
                <header class="header large-12 columns">
                    <div class="row">
                        <div class="logo large-4 columns">
                            <h1><a class='current' href="<?php echo e('/'); ?>"><img src="<?php echo e(asset('images/logo.png')); ?>" alt="" /></a></h1>
                        </div><!-- /logo -->                    
                        <div class="large-8 columns">
                            <nav id="nav">                          
                                <?php if(Auth::check()): ?>
                                    <ul id="navigation" class="group">                              
                                        <li class="current-menu-item">
                                            <a href="index.html"><?php echo app('translator')->getFromJson('home.language_menu'); ?></a>
                                            <ul>
                                                <li><a href="locale/en">English</a></li>
                                                <li><a href="locale/jp">Japan</a></li>                  
                                                <li><a href="locale/ru">Russian</a></li> 
                                            </ul>
                                        </li>      
                                        <li class="current-menu-item">
                                            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                                <?php echo app('translator')->getFromJson('home.logout_menu'); ?>
                                            </a>
                                        </li>   
                                        <li class="current-menu-item"><a href="<?php echo e(url('admin')); ?>"><?php echo app('translator')->getFromJson('home.admin_menu'); ?></a></li>     
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                        <li class="current-menu-item"><a href="<?php echo e(url('contact')); ?>"><?php echo app('translator')->getFromJson('home.contact_menu'); ?></a></li>  
                                    </ul><!-- #navigation -->
                                <?php else: ?>
                                    <ul id="navigation" class="group">      
                                        <li class="current-menu-item">
                                            <a href="index.html">HOME</a>
                                            <ul>
                                                <li><a href="index_alt.html">HOME ALT #1</a></li>
                                                <li><a href="index_alt2.html">HOME ALT #2</a></li>                  
                                            </ul>
                                        </li>                           
                                        <li class="current-menu-item"><a href="<?php echo e(url('login')); ?>">Login</a></li>
                                        <li class="current-menu-item"><a href="<?php echo e(url('register')); ?>">Signup</a></li>
                                        <li class="current-menu-item"><a href="<?php echo e(url('contact')); ?>">contact</a></li> 
                                        <li class="current-menu-item">
                                            <a href="index.html">HOME</a>
                                            <ul>
                                                <li><a href="index_alt.html">HOME ALT #1</a></li>
                                                <li><a href="index_alt2.html">HOME ALT #2</a></li>                  
                                            </ul>
                                        </li>                           
                                    </ul><!-- #navigation -->
                                <?php endif; ?>
                            </nav><!-- #nav -->
                        </div>                  
                    </div>
                </header><!-- /header -->
            </div><!-- /row -->
        </div><!-- /top-wrap-->

        <div id="section" style="background:url(<?php echo e(asset('images/homebanner.jpg')); ?>) no-repeat top center">
            <div class="row">
                <div class="large-12 columns">
                    <h3><?php echo app('translator')->getFromJson('home.Home_title'); ?></h3>
                </div><!-- /large-12 -->
            </div><!-- /row -->
        </div><!-- /section -->
        
    </div><!-- /header-wrap -->

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->yieldContent('footer_scripts'); ?>

<?php echo $__env->yieldContent('credits_wrap'); ?>


<script type="text/javascript" src="<?php echo e(asset('js/jquery-1.10.1.min.js')); ?>"></script>        
<script type="text/javascript" src="<?php echo e(asset('js/superfish-1.7.2.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.flexslider-min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.fitvids.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.equalHeights.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jRespond.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.jpanelmenu.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/soundmanager2.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/inlineplayer.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.prettyPhoto.js')); ?>">
    
</script>

<script type="text/javascript" src="<?php echo e(asset('js/scripts.js')); ?>"></script>      

</body>
</html>
