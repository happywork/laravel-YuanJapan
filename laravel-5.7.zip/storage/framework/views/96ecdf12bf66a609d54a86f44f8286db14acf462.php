<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php if(trim($__env->yieldContent('template_title'))): ?><?php echo $__env->yieldContent('template_title'); ?> | <?php endif; ?> <?php echo e(config('app.name', Lang::get('titles.app'))); ?></title>
        <meta name="description" content="">
        <meta name="author" content="Maxsim">
        <link rel="shortcut icon" href="/favicon.ico">

        
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

        
        <?php echo $__env->yieldContent('template_linked_fonts'); ?>

                
        <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
        <link href="<?php echo e(asset('css/flexslider.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/foundation.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/normalize.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/prettyPhoto.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/default.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">	

        <?php echo $__env->yieldContent('template_linked_css'); ?>

        <style type="text/css">
            <?php echo $__env->yieldContent('template_fastload_css'); ?>
        </style>

        
        <script>
            window.Laravel = <?php echo json_encode([
                'csrfToken' => csrf_token(),
            ]); ?>;
        </script>        

        <?php echo $__env->yieldContent('head'); ?>

    </head>
    <body class="home">
        <?php echo $__env->yieldContent('content'); ?>
    <div id="mobile-bar">
	<a class="menu-trigger" href="#"></a>
	<h1 class="mob-title">Club 88</h1>
</div>
 
<?php echo $__env->yieldContent('section_nav_menu'); ?>

<?php echo $__env->yieldContent('section_title_part'); ?>

</div><!-- /header-wrap -->

<div id="main-wrap">
	<div id="main" class="row">		
		<?php echo $__env->yieldContent('main_content'); ?>
		<?php echo $__env->yieldContent('right_sidebar_content'); ?>		
	</div><!-- /main -->
</div><!-- /main-wrap -->

<?php echo $__env->yieldContent('footer_scripts'); ?>

<?php echo $__env->yieldContent('credits_wrap'); ?>


<script type="text/javascript" src="<?php echo e(asset('js/jquery-1.10.1.min.js')); ?>"></script>        
<script type="text/javascript" src="<?php echo e(asset('js/superfish-1.7.2.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.flexslider-min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.fitvids.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.equalHeights.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jRespond.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.jpanelmenu.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/soundmanager2.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/inlineplayer.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.prettyPhoto.js')); ?>">
    
</script>

<script type="text/javascript" src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/modernizr.js')); ?>"></script>
<script src="http://maps.google.com/maps/api/js?sensor=false"></script>        

</body>
</html>
